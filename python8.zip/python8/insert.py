
db.getCollection('clients').insertMany([
    {
       
  "nom": "hajar",
  "prenom": "elafkih",
  "cin": "AB123",
  "email": "hajar@gmail.com",
  "telephone": "0628489416"
    },
    {
  "nom": "wissal",
  "prenom": "elouafy",
  "cin": "ABC123",
  "email": "wissal@gmail.com",
  "telephone": "0628489536"
    },
     {
  "nom": "nada",
  "prenom": "rayadi",
  "cin": "ABG45",
  "email": "rayadi@gmail.com",
  "telephone": "0628489548",
    },
    
  
   
]);
